# GRIHAMAKER AI starter
A real backend-connected starter with AI-provider calls, live Wikipedia/OpenAlex source search, editable answers, regenerate, and browser-local history.

## Run
1. Install Node.js 18 or newer.
2. Extract the ZIP and open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`; put your own provider key in `AI_API_KEY`.
5. Run `npm start` and open `http://localhost:3000`.

Never put the API key in frontend code or publish `.env`. AI provider usage may cost money. Search is limited to Wikipedia and OpenAlex in this starter, not a full search engine. Chat history is browser-local, not cloud synced. Public deployment needs authentication, rate limits, privacy controls, and a managed database.
